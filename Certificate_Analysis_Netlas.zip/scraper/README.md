run the following to get all libraries:
pip install -r requirements.txt

run main.py for both parsing and scraping (very easy to make them run seperately if we want)

TODO:
edit scraper when format is known
save certs to file or change dataset, idk do smth with results
