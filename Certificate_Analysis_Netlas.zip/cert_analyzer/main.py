import netlas
import os
import json
from dotenv import load_dotenv

from cert_analyzer.netlas_parser import parse_netlas_result
from cert_analyzer.analysis.basic_analysis import analyze_netlas_result

load_dotenv()

## python3 -m cert_analyzer.main


if __name__ == "__main__":

    API_KEY = os.getenv("NETLAS_API_KEY")
    query = "certificate.subject_dn:aau.dk"

    netlas_connection = netlas.Netlas(API_KEY)
    raw_results = netlas_connection.search(query, datatype="cert")

    netlas_result = parse_netlas_result(raw_results)

    analyze_netlas_result(netlas_result)










    
    # API_KEY = os.getenv("NETLAS_API_KEY")   
    # query = "certificate.subject_dn:aau.dk"

    # netlas_connection = netlas.Netlas(API_KEY)

    # search_results = netlas_connection.search(
    #     query, datatype="cert"
    # )

    # # Save results to a JSON file
    # with open("results.json", "w") as f:
    #     json.dump(search_results, f, indent=4)

    # print("Results saved to results.json")