import csv
import netlas
import os
import json
from dotenv import load_dotenv

from cert_analyzer.netlas_parser import parse_netlas_result
from cert_analyzer.analysis.basic_analysis import analyze_netlas_result
import pandas
from domain_analyzer.extration import parse_domain_features, parse_whois_feautures, process_domain, parse_whois_feautures

load_dotenv()

## python3 -m cert_analyzer.main


if __name__ == "__main__":

    input_path=input("Enter Input path: ").strip()
    output_path=input("Enter Output path: ").strip()


    df=pandas.read_csv(input_path)
    process_domain(df, output_path)
