import netlas
import json

if __name__=="__main__":
    API_KEY="Y3cVJmGgs6HCRFfyDr9mJ5EjygNoyvYO"
    netlas_connection = netlas.Netlas(API_KEY)
    query = "domain:madamblue.dk"

    raw_results = netlas_connection.search(query, datatype="whois-domain")

    with open("results.json", "w") as f:
        json.dump(raw_results, f, indent=4)

    print("Results saved to results.json")