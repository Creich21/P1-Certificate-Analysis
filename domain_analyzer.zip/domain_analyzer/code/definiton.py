from dataclasses import dataclass
import datetime


@dataclass
class Domain:
    #domain_name: str
    length: int
    shannon_entropy: float
    token_count:int
    hyphen_count:int
    subdomain_count:int
    suspicious_keywords_count: int
    suspicious_keywords: list[str]
    brand_inclusion: list[str]
    idn_punycode: bool
    idn_hymoglyph: bool
    dns_ttl: int
    ip: str
    hosting_asn: int

    

class Whois:
    creation_date: datetime
    expiration_date: datetime
    registrar: str
    registrant_country: str
    registrant_city: str
    registrant_name: str
    status: str