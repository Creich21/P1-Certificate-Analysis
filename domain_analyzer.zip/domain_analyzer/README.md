run main.py

filtered_tranco_dataset.csv is the benign dataset
-> use at input-path for like "data/filtered_tranco_dataset.csv"

blocked_merge.csv is the malicious dataset without duplicates
-> -> use at input-path for like "data/blocked_merge.csv"

The file test.csv is a subset of the benign dataset to test the script. The output file is test_out.csv where you can see extrcated features and how it will look like.

